## Project Overview

* Build an AI scheduler that optimizes a student’s daily study plan using a Genetic Algorithm.

* Separate the "Intelligent Solver" (GA + Fitness + optional Fuzzy layer) from the application (API + UI + DB).

* Deliver a working demo with clear visualization and rationale for each scheduled block.

## Tech Stack

* Backend: Python 3.10+, FastAPI, Pydantic; SQLite for persistence (via SQLAlchemy or lightweight DAO).

* AI Engine: Pure Python GA module (no heavy libraries), optional simple fuzzy rules implemented manually.

* Frontend: React (Vite) or minimal HTML/JS if time-constrained; consume REST APIs.

## Data & Knowledge Representation

* Entities: `Subject`, `Task`, `StudentProfile`, `Slot`, `Schedule`.

* State (Chromosome): 2D structure (Days × TimeSlots). Each gene holds a `StudyBlock {task_id, subject_id, duration, difficulty, energy_need}`.

* Knowledge: JSON/DB entries for subject traits (focus demand, difficulty), student circadian preferences (e.g., night owl), blocked times (sleep, classes).

## Constraints & Fitness

* Hard constraints (must pass):

  * No overlaps; respect blocked times; total daily duration cap; mandatory breaks every 2 hours.

* Soft constraints (maximize):

  * Align high-difficulty subjects with peak energy; distribute subjects to avoid monotony; proximity to deadlines; preferred study windows.

* Fitness function:

  * `Score = W_soft*soft_score - W_fatigue*fFatigue - W_violations*hard_penalty`.

  * Large penalties for any hard-constraint violation; use a repair step to fix common violations post-crossover/mutation.

## Optional Fuzzy Layer (Recommended)

* Inputs: `time_of_day`, `subject_difficulty`.

* Rule example: IF time is Late AND difficulty is High THEN fatigue risk is High.

* Output: numeric fatigue risk multiplier added to fitness cost.

* Implementation: simple rule base with piecewise membership functions in code.

## GA Engine

* Initialization: generate feasible random schedules honoring blocked times and basic break rules.

* Evaluation: compute fitness for all individuals.

* Selection: tournament selection (k=3).

* Crossover: single-point at day boundary (swap contiguous day ranges); probability 0.8.

* Mutation: move or swap a study block; probability 0.1; apply repair.

* Elitism: carry top-N (e.g., 2) each generation.

* Termination: max generations (e.g., 100) or convergence threshold.

* Reproducibility: deterministic RNG seed support.

## API Design

* `POST /subjects` CRUD for subjects.

* `POST /tasks` CRUD for tasks (title, subject\_id, duration, deadline, difficulty).

* `POST /profile` set energy preferences and blocked times.

* `POST /optimize` run GA with current data; params: days span, slot size, generations; returns schedule + rationale.

* `GET /schedule/:id` fetch saved schedule.

## Frontend Features

* Input forms: subjects, tasks, preferences (energy curve sliders, blocked time pickers).

* Scheduler grid (Days × TimeSlots) with color-coded subjects and break markers.

* Rationale tooltip per block: "Scheduled Math at 10:00 due to peak energy and upcoming deadline".

* Controls: regenerate, tweak weights (fatigue vs deadline), save schedule.

## Visualization & Explainability

* Highlight high-difficulty blocks scheduled at peak energy.

* Indicators for breaks and blocked times.

* Fitness summary: total score, penalties, soft matches.

## Testing & Validation

* Unit tests: fitness components, constraint checker, mutation/crossover invariants, repair function.

* Integration: end-to-end optimize call with seeded data; verify no hard violations.

* Determinism: test with fixed RNG seed for consistent results.

## Ethical & Usability Safeguards

* Enforce daily max study hours; mandatory breaks; warn on excessive load.

* Allow student override with clear visibility of trade-offs.

## Deliverables & Milestones

* Phase 1 (40%): data structures, constraint checker, basic fitness; GA loop skeleton; sample input; flowchart.

* Phase 2: full GA (selection/crossover/mutation/elitism), repair, optional fuzzy layer.

* Phase 3: API + minimal UI; visualization + rationale; tests; demo script.

## Alignment to Marking Criteria

* Factored state (chromosome) and action space (move/swap blocks).

* Knowledge representation via subject traits and student profile.

* CSP via constraints embedded in fitness with repair and logic check.

* GA strategy per spec: population 50, tournament selection, single-point crossover, mutation.

* Optional fuzzy logic for fatigue risk integrated into fitness.

## Next Step (upon approval)

* Scaffold backend and GA modules; implement data models and constraint/fitness; add GA operators; expose `/optimize`; build minimal React UI to visualize schedules and rationales; write unit tests and an E2E demo seed.

